package so;

public enum Priority {
	BAIXA, MEDIA, ALTA, CRITICA;
}
