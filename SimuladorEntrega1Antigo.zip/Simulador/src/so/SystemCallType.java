package so;

public enum SystemCallType {
	DELETE_PROCESS, CREATE_PROCESS, WRITE_PROCESS;
}
